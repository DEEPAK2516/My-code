#include <stdlib.h>
#include <stdio.h>

// Definition of linked list node
struct lnode {
    int data;
    struct lnode* next;
};

// Alias for the struct
typedef struct lnode node;

// Function to create a new node with given data
node* create_node(int data) {
    // Dynamically allocate memory for the new node
    node* new_node = (node*) malloc(sizeof(node));
    // Set the node's data to the given data
    new_node->data = data;
    // Set the node's next pointer to NULL
    new_node->next = NULL;
    // Return the new node
    return new_node;
}

// Function to insert a new node at the beginning of the list
void insert_at_begging(node **head, int data) {
    // Create a new node with the given data
    node *newnode = create_node(data);
    // If the list is empty, make the new node the head of the list
    if (*head == NULL) {
        *head = newnode;
    // If the list is not empty, make the new node the new head of the list
    } else {
        newnode->next = *head;
        *head = newnode;
    }
    // Print a message indicating the data that was inserted
    printf("inserted : %d\n", data);
}

// Function to insert a new node at the end of the list
void insert_at_end(node **head, int data) {
    // Create a new node with the given data
    node *newnode = create_node(data);
    // If the list is empty, make the new node the head of the list
    if (*head == NULL) {
        *head = newnode;
    // If the list is not empty, find the last node and make its next pointer point to the new node
    } else {
        node *temp  = *head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newnode;
    }
    // Print a message indicating the data that was inserted
    printf("inserted : %d\n", data);
}

// Function to insert a new node at a given position in the list
void insert_at_posititon(node **head,int pos,int data){
    // If the position is 0, insert the node at the beginning of the list
    if(pos == 0){
        insert_at_begging(&(*head),data);
        return;
    }
    // Traverse the list to find the node before the desired position
    node *temp  =*head;
    for(int i=0;i<pos-1;i++){
        temp  = temp->next;
        // If the position is invalid, print an error message and return
        if(temp == NULL){
            printf("invalid position\n");
            return;
        }
    }
    // If the next node is NULL, insert the new node at the end of the list
    if(temp->next == NULL){
        insert_at_end(&(*head),data);
        return;
    }
    // Otherwise, create a new node and insert it between the current node and the next node
    node *newnode = create_node(data);
    newnode->next = temp->next;
    temp->next = newnode;
}

void display(node **head) {
    if (*head == NULL) { // if the head is NULL, the list is empty
        printf("list empty");
        return;
    }
    node *temp  = *head; // create a temporary pointer to the head node
    while (temp != NULL) { // loop through the list until the end is reached (temp == NULL)
        printf("%d ", temp->data); // print the data in the current node
        temp = temp->next; // move to the next node
    }
    printf("\n"); // print a newline character at the end
}

void deletion_at_end(node **head){
    if(*head==NULL){ // if the list is empty (head is NULL), print a message and return
        printf("empty list\n");
        return;
    }
    node *temp = *head; // create a temporary pointer to the head node
    while(temp->next->next!=NULL){ // loop until the second last node is reached
        temp  =temp->next; // move to the next node
    }
    node *del  = temp->next; // create a pointer to the last node
    temp->next = NULL; // set the second last node's next pointer to NULL
    printf("deleted:%d\n",del->data); // print the data of the deleted node
    free(del); // free the memory of the deleted node
}

void deletion_at_begining(node **head){
    if(*head == NULL){
        printf("empty list\n");
        return;
    }
    // keep track of the node to be deleted
    node *del = *head;
    // move the head pointer to the second node
    *head = (*head)->next;
    // print the data of the deleted node
    printf("deleted:%d\n",del->data);
    // free the memory occupied by the deleted node
    free(del);
}

void deletion_at_posititon(node **head,int pos){
    if(pos == 0){                   // if deleting at the beginning of the list
        deletion_at_begining(&(*head));
        return;
    }
    node *temp  = *head,*prev;
    for(int i=0;i<pos;i++){         // traverse the list to find the node to be deleted
        prev = temp;
        temp = temp->next;
        if(prev->next==NULL){       // if we reach the end of the list before reaching the specified position, position is invalid
            printf("invalid position\n");
            return;
        }
    }
    if(temp==NULL){                 // if the node to be deleted is the last node
        deletion_at_end(&(*head));
        return;
    }
    node *del = temp;               // delete the node
    prev->next = temp->next;
    printf("deleted:%d\n",del->data);
    free(del);
}

int main() {
    // use functions like this
    node *list1 = NULL;
    insert_at_begging(&list1,12);
}


