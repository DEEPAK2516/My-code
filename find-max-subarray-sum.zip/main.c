/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
int current=0,answer=arr[0];
    for(int i=0;i<n;i++){
        current+=arr[i];
        if(answer<current){
            answer=current;
        }
        if(current<=0){
            current=0;
        }
    }
    return answer;
    }
*******************************************************************************/
#include <stdio.h>

int main()
{
    int size;
    scanf("%d",&size);
    int arr[size];
    for(int i=0;i<size;i++){
        scanf("%d",&arr[i]);
    }
    int current = 0;
    int answer = arr[0];
    for(int i=0;i<size;i++){
        current+=arr[i];
        if(answer<current){
            answer = current;
        }
        if(current <=0){
            current   = 0;
        }
    }
    printf("%d ",answer);
}
