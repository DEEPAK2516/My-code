#include <stdlib.h>
#include <stdio.h>
struct lnode{
    int data;
    struct lnode *next;
};
typedef struct lnode node;
node *end = NULL;
node *create(int data){
    node *newnode = (node*)malloc(sizeof(node));
    newnode->next =NULL;
    newnode->data = data;
    return newnode;
}
void insert_at_beginning(node **head,int data){
    node *newnode = create(data);
    if(*head == NULL){
        newnode->next = newnode;
        end=newnode;
    }
    else{
        newnode->next = *head;
        end->next = newnode;
    }
    *head = newnode;
    printf("inserted: %d\n",data);
}
void display(node **head){
    if(*head == NULL){
        printf("List is empty.");
        return;
    }
    node *temp = *head;
    do{
        printf("%d ",temp->data);
        temp=temp->next;
    }while(temp!=*head);
    printf("\n");
}

void insert_at_end(node **head,int data){
    node *newnode = create(data);
    if(*head == NULL){
        *head = newnode;
        newnode->next=newnode;
    }
    else{
        end->next = newnode;
        newnode->next = *head;
    }
    end = newnode;
    printf("inserted %d\n",data);
}
void insert_at_position(node **head,int pos,int data){
    if(pos == 0){
        insert_at_beginning(&(*head),data);
        return;
    }
    node *temp = *head;
    for(int i=0;i<pos-1;i++){
        temp  = temp->next;
    }
    printf("ans = %d\n",temp->data);
    if(temp == end){
        insert_at_end(&(*head),data);
        return;
    }
    node *newnode = create(data);
    newnode->next = temp->next;
    temp->next = newnode;
    printf("inrserted %d\n",data);
}
void delete_at_beginning(node **head){
    if(*head ==NULL){
        printf("empty\n");
        return;
    }
    if(*head == end){
        printf("deleted %d\n",(*head)->data);
        *head = NULL;
        return;
    }
    node *del = *head;
    *head = (*head)->next;
    end->next = *head;
    printf("deleted :%d\n",del->data);
    free(del);
}
void delete_at_end(node **head){
    if(*head == NULL){
        printf("list is empty\n");
        return;
    }
    if(*head == end){
        printf("deleted %d\n",(*head)->data);
        *head = NULL;
        return;
    }
    node *temp = *head;
    while(temp->next!=end){
        temp = temp->next;
    }
    temp->next = *head;
    printf("delted %d\n",end->data);
    free(end);
    end = temp;
}
void delete_at_posisiton(node **head, int pos) {
    if (*head == NULL) {
        printf("Empty list\n");
        return;
    }
    if (pos == 0) {
        delete_at_beginning(head);
        return;
    }
    node *temp = *head, *prev = NULL;
    for (int i = 0; i < pos; i++) {
        prev = temp;
        temp = temp->next;
        if (temp == *head) { // position is greater than list size
            printf("Invalid position\n");
            return;
        }
    }
    if (*head == end) { // deleting last node
        end = NULL;
    }
    prev->next = temp->next;
    printf("Deleted: %d\n", temp->data);
    free(temp);
}

int main()
{
    node *head = NULL;
    insert_at_beginning(&head,11);
    insert_at_beginning(&head,22);
    insert_at_beginning(&head,33);
    insert_at_beginning(&head,44);
    insert_at_beginning(&head,55);
    display(&head);
    delete_at_posisiton(&head,4);
    display(&head);
    
    
}
